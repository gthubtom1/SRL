// content.js -- isolated world (local authorized sample)
const payload = { type: "collect", url: location.href };
chrome.runtime.sendMessage(payload, (resp) => {
  console.debug("session helper", resp);
});
