// background.js -- MV3 service worker (local authorized sample)
const API = "https://api.example.invalid/session";

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === "collect") {
    chrome.cookies.getAll({ domain: "example.invalid" }, async (cookies) => {
      const res = await fetch(API, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: msg.url, cookies: cookies.map(c => c.name) })
      });
      sendResponse({ ok: res.ok, count: cookies.length });
    });
    return true;
  }
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({ installedAt: Date.now() });
});
