// content.js -- local authorized sample
const grab = () => {
  const forms = Array.from(document.forms).map(f => ({
    action: f.action,
    inputs: Array.from(f.elements).map(e => e.name)
  }));
  chrome.runtime.sendMessage({ type: "page-data", url: location.href, forms });
};
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", grab);
} else {
  grab();
}
